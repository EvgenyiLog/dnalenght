# THIS FILE IS GENERATED FROM SETUP.PY
short_version = '0.1.2'
version = '0.1.2'
full_version = '0.1.2.dev0+f4f6416'
git_revision = 'f4f64169fdf15f2da91abbb124a2ad4cbd845165'
release = False

if not release:
    version = full_version
