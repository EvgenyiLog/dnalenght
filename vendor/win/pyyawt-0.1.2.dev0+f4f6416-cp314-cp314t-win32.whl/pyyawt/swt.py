# -*- coding: utf-8 -*-

# Copyright (c) 2015 Holger Nahrstaedt
# See COPYING for license details.

"""
swt function for wavelet
"""

from __future__ import division, print_function, absolute_import
import numpy as np
import sys as sys
from ._pyyawt import *
from .dwt import *

__all__ = ['swt', 'iswt', 'swt2', 'iswt2']


def swt(*args):
    raise Exception("Not yet implemented!!")


def iswt(*args):
    raise Exception("Not yet implemented!!")


def swt2(*args):
    raise Exception("Not yet implemented!!")


def iswt2(*args):
    raise Exception("Not yet implemented!!")
